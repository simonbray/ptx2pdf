#!/bin/sh
cd local/ptxprint/khanty_monoglot
hyph_size=32749 stack_size=32768 FONTCONFIG_FILE=`pwd`/../../../fonts.conf TEXINPUTS=../../../src:. xetex kcaKhPB_khanty_monoglot_JON_ptxp.tex